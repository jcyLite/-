import {createApp} from './app.js';
const {app}=createApp();
app.$mount('#app')
