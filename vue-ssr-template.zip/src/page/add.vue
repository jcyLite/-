<template>
	<div class="page-add">
		<div class="header">
			add
		</div>
	</div>
</template>

<script>
	export default{
		data(){
			return {
				a:[]
			}
		}
	}
</script>

<style>
</style>