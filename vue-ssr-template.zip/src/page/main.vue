<template>
	<div v-if="true" class="hello">
		sdsd
	</div>
</template>

<script>
	export default {
		data(){
			return {
				tabs:['1','2','3']
			}
		}
	}
</script>

<style lang="less">
	.hello{
		background:red;
		margin-top:40px;
	}
</style>