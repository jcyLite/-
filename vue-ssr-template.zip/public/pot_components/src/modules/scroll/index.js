import Scroll from '../../components/scroll/scroll.vue'

Scroll.install = function (Vue) {
  Vue.component(Scroll.name, Scroll)
}

export default Scroll
