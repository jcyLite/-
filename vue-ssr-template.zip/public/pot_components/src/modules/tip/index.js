import Tip from '../../components/tip/tip.vue'

Tip.install = function (Vue) {
  Vue.component(Tip.name, Tip)
}

export default Tip
