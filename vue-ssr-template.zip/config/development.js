process.env.NODE_ENV='development';
const developBase=require('./development.base.js');
new developBase('src');